=== AspieSoft WP Plugin Icons ===
Contributors: AspieSoft
Tags: AspieSoft, plugin, icon
Requires at least: 3.0.1
Tested up to: 5.8
Stable tag: 1.0.3
Requires PHP: 5.2.4
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html
Donate link: https://buymeacoffee.aspiesoft.com

== Description ==
Puts icons next to the wordpress plugins in your installed plugins list to make navigation easier.

== Installation ==

1. Upload plugin to the /wp-content/plugins
2. Activate the plugin through the "Plugins" menu in WordPress
3. Enjoy

== Changelog ==

= 1.0 =
Initial Commit

== Upgrade Notice ==

= 1.0 =
Initial Commit

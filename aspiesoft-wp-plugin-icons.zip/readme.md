# WP Plugin Icons

Puts icons next to the wordpress plugins in your installed plugins list to make navigation easier.

## CDN Installation

```html
<script src="https://cdn.jsdelivr.net/gh/AspieSoft/wp-plugin-icons@1.0.3/wp-plugin/trunk/assets/script.js"></script>
```

---

## Wordpress Installation

1. Upload plugin to the /wp-content/plugins
2. Activate the plugin through the "Plugins" menu in WordPress
3. Enjoy
